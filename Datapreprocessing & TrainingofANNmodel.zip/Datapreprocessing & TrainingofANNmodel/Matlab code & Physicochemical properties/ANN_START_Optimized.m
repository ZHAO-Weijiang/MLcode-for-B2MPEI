clc;
clear all;
%*******************************************************************************************************
%the code aims to input the features and the labels to training a prediction neutral network function
%*******************************************************************************************************

% The file path of input data and output data
Location = 'D:\Datapreprocessing & TrainingofANNmodel\Fe-Co-Ni-Ti-Zr\features.xlsx';
outputFolder = 'D:\Datapreprocessing & TrainingofANNmodel\Fe-Co-Ni-Ti-Zr';

% Read the input data and transfer the one-hot label into class label
features = xlsread(Location,1,'A1:R1000');
labels = xlsread(Location,1,'S1:U1000');
t_cate = categorical(vec2ind(labels')');

% Random rearrangement of features
Num = length(features);
n = width(features);
Ran = randperm(Num);
for a=1:Num
    Featureset(a,:) = features(Ran(a),:);
    T_cate(a,:) = t_cate(Ran(a),:);
end

% Definition of best combination of hyperparameters
bestParams = struct(...
    'Optimizer', 'rmsprop', ...
    'LearningRate', 0.1, ...
    'Regularization', 0.01, ...
    'Dropout', 0.3, ...
    'HiddenSize', 20, ...
    'NumFeatures', 18);  % Using all the features

% Construction of neural network with dropout layer
layers = [
    featureInputLayer(bestParams.NumFeatures, 'Name', 'input')
    fullyConnectedLayer(bestParams.HiddenSize, 'Name', 'fc1', ...
    'WeightL2factor', bestParams.Regularization)
    sigmoidLayer('Name', 'sigmoid')
    dropoutLayer(bestParams.Dropout, 'Name', 'dropout')
    fullyConnectedLayer(3, 'Name', 'fc_out')
    softmaxLayer('Name', 'softmax')
    classificationLayer('Name', 'output')
];

% Separation of datasets for training, tesing and validating
rng('default');
totalSamples = length(features);
trainRatio = 0.7;
valRatio = 0.15;
testRatio = 0.15;

trainInd = 1:floor(totalSamples*trainRatio);
valInd = (max(trainInd)+1):(max(trainInd)+floor(totalSamples*valRatio));
testInd = (max(valInd)+1):totalSamples;

% Construction of training options
options = trainingOptions(bestParams.Optimizer, ...
    'Plots', 'none', ...
    'MaxEpochs', 1000, ...
    'ValidationFrequency', 30, ...
    'ValidationPatience', 6, ...
    'InitialLearnRate', bestParams.LearningRate, ...
    'ExecutionEnvironment', 'cpu', ...
    'GradientThreshold', 1, ...
    'Verbose', false, ...
    'ValidationData', {Featureset(valInd,:), T_cate(valInd)});

% Training the Network
fprintf('Training of the optimal ANN model...\n');
net = trainNetwork(Featureset(trainInd,:), T_cate(trainInd), layers, options);
fprintf('Training complete\n');

% Obtaining the information of network layer
fprintf('Extracting the key parameters of ANN...\n');
layerNames = {net.Layers.Name};
fc1Idx = find(strcmp(layerNames, 'fc1'));
fcOutIdx = find(strcmp(layerNames, 'fc_out'));

IW1_1 = net.Layers(fc1Idx).Weights;   % Weights of hidden layer
b1 = net.Layers(fc1Idx).Bias;         % Bias of hidden layer
LW2_1 = net.Layers(fcOutIdx).Weights; % Weights of output layer
b2 = net.Layers(fcOutIdx).Bias;       % Bias of output layer

% Generating the MATLAB function for prediction
fprintf('Gennerating the prediction function...\n');
funcPath = fullfile(outputFolder, 'FeCoNiTiZr18_o2.m');
generatePredictFunction(funcPath, IW1_1, b1, LW2_1, b2, bestParams);

fprintf('The prediction function has been generated: %s\n', funcPath);

% Definition the auxiliary function for generating independent prediciton function
function generatePredictFunction(filePath, IW1_1, b1, LW2_1, b2, params)
fid = fopen(filePath, 'w');

fprintf(fid, 'function [y1, probabilities, LW2_1, IW1_1] = FeCoNiTiZr18_o2(x1)\n');
fprintf(fid, '%%ALLOYPHASEPREDICTOR Predict alloy phase probabilities\n');
fprintf(fid, '%%   [y1, probabilities] = alloyPhasePredictor(x1) predicts phase probabilities\n');
fprintf(fid, '%%   for given alloy features.\n');
fprintf(fid, '%%\n');
fprintf(fid, '%%   INPUT:\n');
fprintf(fid, '%%       x1 - Qx%d matrix of input features (Q samples, %d features)\n', params.NumFeatures, params.NumFeatures);
fprintf(fid, '%%   OUTPUT:\n');
fprintf(fid, '%%       y1 - Qx3 matrix of output probabilities\n');
fprintf(fid, '%%       probabilities - same as y1\n\n');

fprintf(fid, '%% ===== NEURAL NETWORK CONSTANTS =====\n\n');

fprintf(fid, '%% Input 1\n');
fprintf(fid, 'IW1_1 = [ ...\n');
writeMatrix(fid, IW1_1);
fprintf(fid, '];\n\n');

fprintf(fid, '%% Layer 1\n');
fprintf(fid, 'b1 = [ ...\n');
writeVector(fid, b1);
fprintf(fid, '];\n\n');

fprintf(fid, '%% Layer 2\n');
fprintf(fid, 'b2 = [ ...\n');
writeVector(fid, b2);
fprintf(fid, '];\n\n');

fprintf(fid, 'LW2_1 = [ ...\n');
writeMatrix(fid, LW2_1);
fprintf(fid, '];\n\n');

fprintf(fid, '%% ===== SIMULATION ========\n\n');
fprintf(fid, '%% Dimensions\n');
fprintf(fid, 'Q = size(x1,1); %% samples\n\n');

fprintf(fid, '%% Input 1\n');
fprintf(fid, 'xp1 = x1''; %% Transpose to features x samples\n\n');

fprintf(fid, '%% Layer 1\n');
fprintf(fid, 'a1 = sigmoid_apply(IW1_1 * xp1 + b1);\n\n');

fprintf(fid, '%% Layer 2\n');
fprintf(fid, 'a2 = softmax_apply(LW2_1 * a1 + b2);\n\n');

fprintf(fid, '%% Output 1\n');
fprintf(fid, 'y1 = a2'';\n');
fprintf(fid, 'probabilities = y1;\n');
fprintf(fid, 'end\n\n');

fprintf(fid, '%% ===== HELPER FUNCTIONS ========\n\n');
fprintf(fid, '%% Sigmoid Transfer Function\n');
fprintf(fid, 'function a = sigmoid_apply(n)\n');
fprintf(fid, 'a = 1 ./ (1 + exp(-n));\n');
fprintf(fid, 'end\n\n');

fprintf(fid, '%% Softmax Transfer Function\n');
fprintf(fid, 'function a = softmax_apply(n)\n');
fprintf(fid, 'nmax = max(n, [], 1);\n');
fprintf(fid, 'n = bsxfun(@minus, n, nmax);\n');
fprintf(fid, 'numerator = exp(n);\n');
fprintf(fid, 'denominator = sum(numerator, 1);\n');
fprintf(fid, 'denominator(denominator == 0) = 1; %% Prevent division by zero\n');
fprintf(fid, 'a = bsxfun(@rdivide, numerator, denominator);\n');
fprintf(fid, 'end\n');

fclose(fid);
end

% Auxiliary function for writing the matrix
function writeMatrix(fid, matrix)
[rows, cols] = size(matrix);
for i = 1:rows
    fprintf(fid, '    ');
    for j = 1:cols
        fprintf(fid, '%.10f', matrix(i,j));
        if j < cols
            fprintf(fid, ' ');
        end
    end
    if i < rows
        fprintf(fid, '; ...\n');
    else
        fprintf(fid, ' ...\n');
    end
end
end

% Auxiliary function for writing the vector
function writeVector(fid, vector)
for i = 1:length(vector)
    fprintf(fid, '    %.10f', vector(i));
    if i < length(vector)
        fprintf(fid, '; ...\n');
    else
        fprintf(fid, ' ...\n');
    end
end
end