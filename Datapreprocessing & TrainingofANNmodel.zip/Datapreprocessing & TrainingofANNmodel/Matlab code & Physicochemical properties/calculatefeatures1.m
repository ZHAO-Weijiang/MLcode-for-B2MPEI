function[features] = calculatefeatures1(comp, ele_frac, data1_ld, data2_ld)
    
    %  Initializng the matrix composed of physicochemical properties
    ntotal = length(comp);
    radius = data1_ld(comp, 1);       % atom radius
    tm = data1_ld(comp, 2);           % melting point
    elec_nega = data1_ld(comp, 3);    % electronegativity
    vec = data1_ld(comp, 4);          % valence electron concentration
    Young = data1_ld(comp, 5);        % Young's modulus
    bulk = data1_ld(comp, 6);         % bulk modulus
    u = data1_ld(comp, 7);            % Poisson's ratio
    density = data1_ld(comp, 8);      % density
    atomic_mass = data1_ld(comp, 9);  % atomic mass
    enthalpy = data2_ld(comp, comp);  % mixing enthalpy
    
    % Normalizing the fraction of elements
    ele_frac = ele_frac / sum(ele_frac);
    
    % Calculation of useful classic descriptors
    r_mean = sum(ele_frac .* radius);
    delta = sqrt(sum(ele_frac .* (1 - radius / r_mean).^2));

    TM = sum(ele_frac .* tm);

    Mean_elecnega = sum(ele_frac .* elec_nega);
    D_elecnega = sqrt(sum(ele_frac .* (elec_nega - Mean_elecnega).^2));

    MVEC = sum(ele_frac .* vec);

    Sid = -8.31 * sum(ele_frac .* log(ele_frac));

    % Calculation of new physics-informed descriptors
    [output1, output2, output3, output_1_2, frac1_2, frac2_1] = ...
        calculatePBSfeatures(comp, ele_frac, enthalpy, data1_ld, data2_ld);

    features14_1 = calculate_log_feature(output1);
    features14_2 = calculate_log_feature(output2);
    
    % Obtaining the matrix of features
    features = zeros(18, 1);
    features(1) = r_mean;
    features(2) = output3(2);
    features(3) = TM;
    features(4) = output_1_2(4);
    features(5) = output3(5);
    features(6) = output3(6);
    features(7) = output_1_2(7);
    features(8) = Mean_elecnega;
    features(9) = D_elecnega;
    features(10) = MVEC;
    features(11) = output3(11);
    features(12) = output_1_2(5);
    features(13) = output_1_2(6);
    features(14) = output_1_2(2);
    features(15) = output3(9);
    features(16) = output_1_2(11);
    features(17) = calculate_log_feature1(output3, output_1_2, TM, Sid);
    features(18) = log(output3(2)/(delta*100)+1);
    
    features = features';
end

% logarithm transformation of several descriptors 
function feature_log = calculate_log_feature(output)
    if nargin < 2
        TM = output(3);
    end
    if (output(5) == 0 && output(7) == 0)
        feature_log = -1;
    elseif (output(5) == 0 && output(7) ~= 0)
        feature_log = log(abs(-2 / (-2 - TM * output(7) / 1000)));
    else
        feature_log = log(abs(output(5) / (output(5) - TM * output(7) / 1000)));
    end
end
function feature_log = calculate_log_feature1(output0, output1, TM, Sid)
    if nargin < 2
        TM = output1(3);
    end
    if (output1(7) == 0 && output0(5) == 0)
        feature_log = log(abs(-2 / (-2 - 0.25 * TM * Sid / 1000)));
    elseif (output1(7) ~= 0 && output0(5) == 0)
        feature_log = log(abs(-2 / (-2 - TM * output1(7) / 1000)));
    elseif output0(5) ~= 0
        feature_log = log(abs(output0(5) / (output0(5) - TM * output1(7) / 1000)));
    end
end
