clc;
clear all;
%*********************************************************************************************************************
%the code aims to predict the B2-formation likelihood of generated potential B2 compostions through trained ANN models
%*********************************************************************************************************************

% read the normalized values of descriptors of generated B2 compositions
  % Location = 'D:\Datapreprocessing & TrainingofANNmodel\Fe-Co-Ni-Ti-Zr\Generated.xlsx';
  % xx=xlsread(Location,1,'A1:R2000');

% read the normalized values of descriptors of compositions in pseudo-ternary compositional diagrams
  Location = 'D:\Datapreprocessing & TrainingofANNmodel\Fe-Co-Ni-Ti-Zr\Random.xlsx';
  xx=xlsread(Location,1,'A1:R4852');

% calculate the B2-formation likelihood and coefficients in ANN models 
[y, W2, W1]=ANN_FeCoNiTiZr(xx);

% calculate the matrix of sensitivity coefficients in ANN models
Sensitivity = W2(1, :)*W1;