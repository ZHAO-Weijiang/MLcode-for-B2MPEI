function[features] = calculatefeatures(comp, ele_frac, data1_ld, data2_ld)

    % Initializng the matrix composed of physicochemical properties
    radius = data1_ld(:,1);      % atom radius
    tm = data1_ld(:,2);          % melting point
    elec_nega = data1_ld(:,3);   % electronegativity
    vec = data1_ld(:,4);         % valence electron concentration
    Young = data1_ld(:,5);       % Young's modulus
    bulk = data1_ld(:,6);        % bulk modulus
    u = data1_ld(:,7);           % Poisson's ratio
    density = data1_ld(:,8);     % density
    atomic_mass = data1_ld(:,9); % atomic mass
    enthalpy = data2_ld;         % mixing enthalpy
    ntotal = length(comp);       % number of constituent elements
    
    % Normalizing the fraction of elements
    ele_frac = ele_frac / sum(ele_frac);

    % Obtaining the properties and mixing enthalpy of elements
    ele_size = radius(comp);
    ele_temp = tm(comp);
    ele_elec_nega = elec_nega(comp);
    VEC = vec(comp);
    ele_young = Young(comp);
    ele_bulk = bulk(comp);
    ele_u = u(comp);
    ele_density = density(comp);
    ele_atomicmass = atomic_mass(comp);

    % Calculation of classic descriptors
    r_mean = sum(ele_size .* ele_frac);
    delta = sqrt(sum(ele_frac .* (1 - ele_size / r_mean).^2));

    TM = sum(ele_temp .* ele_frac);
    DTM = sqrt(sum(ele_frac .* (ele_temp - TM).^2));

    Mean_elecnega = sum(ele_elec_nega .* ele_frac);
    D_elecnega = sqrt(sum(ele_frac .* (ele_elec_nega - Mean_elecnega).^2));

    MVEC = sum(VEC .* ele_frac);
    D_VEC = sqrt(sum(ele_frac .* (VEC - MVEC).^2));

    E_ave = sum(ele_young .* ele_frac);
    D_E = sqrt(sum(ele_frac .* (ele_young - E_ave).^2));

    K_ave = sum(ele_bulk .* ele_frac);
    D_K = sqrt(sum(ele_frac .* (ele_bulk - K_ave).^2));

    u_ave = sum(ele_u .* ele_frac);
    D_u = sqrt(sum(ele_frac .* (ele_u - u_ave).^2));

    density_ave = sum(ele_density .* ele_frac);
    D_density = sqrt(sum(ele_frac .* (ele_density - density_ave).^2));

    atomicmass_ave = sum(ele_atomicmass .* ele_frac);
    D_atomicmass = sqrt(sum(ele_frac .* (ele_atomicmass - atomicmass_ave).^2));

    % Calculation of mixing enthalpy and its deviation
    ME = 0;
    DME = 0;
    for i = 1:ntotal-1
        for j = i+1:ntotal
            assert(comp(i) <= size(enthalpy, 1) && comp(j) <= size(enthalpy, 2), ...
       'the index of comp exceeds the range of enthalpy matrix');
            hij = enthalpy(comp(i), comp(j));
            ME = ME + 4 * ele_frac(i) * ele_frac(j) * hij;
            DME = DME + ele_frac(i) * ele_frac(j) * (hij - ME)^2;
        end
    end
    DME = sqrt(DME);

    % Ideal mixing entropy
    Sid = -8.31 * sum(ele_frac .* log(ele_frac));

    % Obtaining the matrix of features
    features = [r_mean, delta, TM, DTM, ME, DME, Sid, ...
                Mean_elecnega, D_elecnega, MVEC, D_VEC, ...
                E_ave, D_E, K_ave, D_K, calculate_log_feature(ME, Sid, TM)];
end

function feature_log = calculate_log_feature(ME, Sid, TM)
    if ME == 0
        feature_log = log(abs(-2 / (-2 - TM * Sid / 1000)));
    else
        feature_log = log(abs(ME / (ME - TM * Sid / 1000)));
    end
end