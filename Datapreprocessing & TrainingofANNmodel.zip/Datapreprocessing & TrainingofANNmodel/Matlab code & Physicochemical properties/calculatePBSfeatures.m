function[output1,output2,output3,output_1_2,frac1_2,frac2_1]=calculatePBSfeatures(comp, ele_frac, enthalpy, data1_ld, data2_ld)

% Definition of output variable matrix
output1 = zeros(13, 1); output2 = zeros(13, 1); output3 = zeros(13, 1);
output_1_2 = zeros(13, 1);

% Calculate the number of composed elements
num_elements = numel(comp);

if num_elements ~= 2
% Initialize the groups
group1_elements = {}; % Group 1 elements
group2_elements = {}; % Group 2 elements
frac1_elements = {}; % Fraction of Group 1 elements
frac2_elements = {}; % Fraction of Group 2 elements

n = num_elements;
rand_indices = randperm(n);
half_n = ceil(n / 2);

group1_elements = comp(rand_indices(1:half_n));
group2_elements = comp(rand_indices(half_n+1:end));
frac1_elements = ele_frac(rand_indices(1:half_n));
frac2_elements = ele_frac(rand_indices(half_n+1:end));

%Mixing enthalpy differing
% Simulated annealing parameters
max_iterations = 1000;
initial_temp = 1000;
final_temp = 1;
cooling_rate = 0.99;

current_temp = initial_temp;
best_group1 = group1_elements;
best_frac1 = frac1_elements;
best_group2 = group2_elements;
best_frac2 = frac2_elements;
best_total_avg_enthalpy = MinimizeMixingEnthalpy(group1_elements, group2_elements,frac1_elements, frac2_elements, enthalpy, comp);

for iter = 1:max_iterations
    % Randomly swap elements between groups
    if ~isempty(group1_elements) && ~isempty(group2_elements)
        swap_idx1 = randi(length(group1_elements));
        swap_idx2 = randi(length(group2_elements));
        new_group1 = group1_elements;
        new_frac1 = frac1_elements;
        new_group2 = group2_elements;
        new_frac2 = frac2_elements;
        new_group1(swap_idx1) = group2_elements(swap_idx2);
        new_frac1(swap_idx1) = frac2_elements(swap_idx2);
        new_group2(swap_idx2) = group1_elements(swap_idx1);
        new_frac2(swap_idx2) = frac1_elements(swap_idx1);

        % Calculate the new total average enthalpy
        new_total_avg_enthalpy = MinimizeMixingEnthalpy(new_group1, new_group2, new_frac1, new_frac2, enthalpy, comp);

        % Decide whether to accept the new solution
        if new_total_avg_enthalpy < best_total_avg_enthalpy || ...
                rand() < exp((best_total_avg_enthalpy - new_total_avg_enthalpy) / current_temp)
            group1_elements = new_group1;
            frac1_elements = new_frac1;
            group2_elements = new_group2;
            frac2_elements = new_frac2;
            if new_total_avg_enthalpy < best_total_avg_enthalpy
                best_group1 = new_group1;
                best_frac1 = new_frac1;
                best_group2 = new_group2;
                best_frac2 = new_frac2;
                best_total_avg_enthalpy = new_total_avg_enthalpy;
            end
        end
    end

    % Decrease the temperature
    current_temp = current_temp * cooling_rate;
    if current_temp < final_temp
        break;
    end
end

% Calcualting the atom number of two optimized sublattices
sum_val1 = 0;
sum_val2 = 0;
for i = 1:length(best_group1)
    sum_val1 = sum_val1 + best_frac1(i);
end

for j = 1:length(best_group2)
    sum_val2 = sum_val2 + best_frac2(j);
end

% Calcualting and moving the extra atoms to another sublattice
frac_var = (max(sum_val1, sum_val2) - min(sum_val1, sum_val2))/2;

if sum_val1 > sum_val2
    new_best_group1 = best_group1;
    new_best_frac1 = best_frac1*(sum_val1-frac_var)/sum_val1;
    new_best_group2 = [best_group2; best_group1];
    new_best_frac2 = [best_frac2; best_frac1*frac_var/sum_val1];
else
    if sum_val1 < sum_val2
    new_best_group2 = best_group2;
    new_best_frac2 = best_frac2*(sum_val2-frac_var)/sum_val2;
    new_best_group1 = [best_group1; best_group2];
    new_best_frac1 = [best_frac1; best_frac2*frac_var/sum_val2];
    end
    if sum_val1 == sum_val2
        new_best_group1 = best_group1; new_best_frac1 = best_frac1;
        new_best_group2 = best_group2; new_best_frac2 = best_frac2;
    end
end

elseif ele_frac(1) > ele_frac(2)
    new_best_group1 = comp(1);
    new_best_group2 = [comp(1), comp(2)];
    new_best_frac1 = ele_frac(1)-(ele_frac(1)-ele_frac(2))/2;
    new_best_frac2 = [(ele_frac(1)-ele_frac(2))/2, ele_frac(2)];
elseif ele_frac(1) < ele_frac(2)
    new_best_group1 = [comp(1), comp(2)];
    new_best_group2 = comp(2);
    new_best_frac1 = [ele_frac(1), (ele_frac(2)-ele_frac(1))/2];
    new_best_frac2 = ele_frac(2)-(ele_frac(2)-ele_frac(1))/2;
else
    new_best_group1 = comp(1);
    new_best_group2 = comp(2);
    new_best_frac1 = ele_frac(1);
    new_best_frac2 = ele_frac(2);
end

num1 = length(new_best_group1);
num2 = length(new_best_group2);

% Insert the sublattice into the output matrix 
output_group1(1:num1, 1) = new_best_group1; output_frac1(1:num1, 1) = new_best_frac1;
output_group2(1:num2, 1) = new_best_group2; output_frac2(1:num2, 1) = new_best_frac2;
disp(output_group1);disp(output_frac1);disp(output_group2);disp(output_frac2);
%Physicochemical properties of Group 1
% [output1(1), output1(2),output1(3),output1(4),output1(5),output1(6),output1(7),output1(8),output1(9),output1(10),output1(11),output1(12),output1(13)] = PhysicalThermodynamicProperties_1(new_best_group1, new_best_frac1, ele_size, ele_tm, ele_en, ele_vec, ele_ym, ele_bm, ele_u, ele_den, ele_am, enthalpy);
[output1(1), output1(2),output1(3),output1(4),output1(5),output1(6),output1(7),output1(8),output1(9),output1(10),output1(11),output1(12),output1(13)] = Physicochemicalproperties1(new_best_group1, new_best_frac1, data1_ld, data2_ld);
%Physicochemical properties of Group 2
% [output2(1), output2(2),output2(3),output2(4),output2(5),output2(6),output2(7),output2(8),output2(9),output2(10),output2(11),output2(12),output2(13)] = PhysicalThermodynamicProperties_1(new_best_group2, new_best_frac2, ele_size, ele_tm, ele_en, ele_vec, ele_ym, ele_bm, ele_u, ele_den, ele_am, enthalpy);
[output2(1), output2(2),output2(3),output2(4),output2(5),output2(6),output2(7),output2(8),output2(9),output2(10),output2(11),output2(12),output2(13)] = Physicochemicalproperties1(new_best_group2, new_best_frac2, data1_ld, data2_ld);

%Average Physicochemical properties of Group 1 and Group 2
summary = 0;
frac1_2 = 0;
frac2_1 = 0;

for i = 1:num1
    summary = summary + new_best_frac1(i);
    frac1_2 = frac1_2 + new_best_frac1(i);
end
for j = 1:num2
    summary = summary + new_best_frac2(j);
    frac2_1 = frac2_1 + new_best_frac2(j);
end
frac1_2 = frac1_2/summary;
frac2_1 = frac2_1/summary;
disp(frac1_2);disp(frac2_1);disp(output1(2));disp(output2(2));
for k = 1:13
output_1_2(k) = output1(k)*frac1_2 + output2(k)*frac2_1;
end

%Physicochemical properties of PBS Intermetallics
[output3(1), output3(2),output3(3),output3(4),output3(5),output3(6),output3(7),output3(8),output3(9),output3(10),output3(11),output3(12),output3(13)] = Physicochemicalproperties2(new_best_group1, new_best_group2, new_best_frac1, new_best_frac2);