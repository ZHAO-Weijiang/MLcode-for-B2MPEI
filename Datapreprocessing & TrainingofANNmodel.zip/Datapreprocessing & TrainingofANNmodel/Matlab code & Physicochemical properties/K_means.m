clc;
clear;
%*****************************************************************************************************************************
%the code aims to perform K-means clustering on the whole dataset derived from random-sublattice-based and classic descriptors
%*****************************************************************************************************************************
xx = xlsread('D:\Datapreprocessing & TrainingofANNmodel\Fe-Co-Ni-Ti-Zr\ABC.xlsx',2,'A1:B1000');

idx = kmeans(xx,3);