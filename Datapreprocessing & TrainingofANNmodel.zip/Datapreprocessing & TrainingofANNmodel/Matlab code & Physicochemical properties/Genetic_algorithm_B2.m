clc;
clear all;
%*********************************************************************************************************************
%the code aims to train a series of ANN models and output their F-measure values
%*********************************************************************************************************************

Location = 'D:\Datapreprocessing & TrainingofANNmodel\Fe-Co-Ni-Ti-Zr\features.xlsx'; % read the labels and normalized descriptors
Location1 = 'D:\Datapreprocessing & TrainingofANNmodel\Fe-Co-Ni-Ti-Zr\Perfomance of different groups.xlsx';  % the storage location of output data

% Randomly select %n descriptors
features = xlsread(Location,1,'A1:R1000');
labels = xlsread(Location,1,'S1:U1000');
Num = size(features,2);
n = width(features);
Nums = 400;% %Nums of trained models
Precision = zeros(Nums, 1);
Recall = zeros(Nums, 1);
F_measure = zeros(Nums, 1);
G_measure = zeros(Nums, 1);
Accuracy = zeros(Nums, 1);
Sensitivity = zeros(Nums, n);
for n1=1:Nums 
    Ran = randperm(Num,n);
    a1=1;
    if a1<=Nums
        for a=1:n
            t = Ran(:,a);
            Featureset(:,a) = features(:,t);
        end
        Featurerecord(n1,:) = Ran;
        a1=a1+1;
    end
    % Traning models using new feature subsets
    x = Featureset';
    t = labels';
    
    trainFcn = 'trainscg';
    % Create a Pattern Recognition Network
    hiddenLayerSize = 20;
    net = patternnet(hiddenLayerSize, trainFcn);
    net.layers{end}.transferFcn = 'softmax';
    
    % Choose Input and Output Pre/Post-Processing Functions
    % For a list of all processing functions type: help nnprocess
    net.input.processFcns = {'removeconstantrows','mapminmax'};
    
    % Setup Division of Data for Training, Validation, Testing
    % For a list of all data division functions type: help nndivision
    net.divideFcn = 'dividerand';  % Divide data randomly
    net.divideMode = 'sample';  % Divide up every sample
    net.divideParam.trainRatio = 70/100;
    net.divideParam.valRatio = 15/100;
    net.divideParam.testRatio = 15/100;
    
    % Choose a Performance Function
    % For a list of all performance functions type: help nnperformance
    net.performFcn = 'crossentropy';  % Cross Entropy
    
    % Choose Plot Functions
    % For a list of all plot functions type: help nnplot
    net.plotFcns = {'plotperform','plottrainstate','ploterrhist', ...
        'plotconfusion', 'plotroc'};
    
    % Train the Network
    [net,tr] = train(net,x,t);
    
    % Test the Network
    y = net(x);
    e = gsubtract(t,y);
    performance = perform(net,t,y);
    tind = vec2ind(t);
    yind = vec2ind(y);
    percentErrors = sum(tind ~= yind)/numel(tind);
    
    % Recalculate Training, Validation and Test Performance
    trainTargets = t .* tr.trainMask{1};
    valTargets = t .* tr.valMask{1};
    testTargets = t .* tr.testMask{1};
    trainPerformance = perform(net,trainTargets,y);
    valPerformance = perform(net,valTargets,y);
    testPerformance = perform(net,testTargets,y);

    % read the confusion matrix
    cm = confusionmat(tind, yind);
    
    % calulate Precision Recall and F-Measure of every class
    num_classes = size(cm, 1); % number of classes
    Precision1 = zeros(1, num_classes);
    Recall1 = zeros(1, num_classes);
    Fbeta1 = zeros(1, num_classes);

    for i = 1:num_classes
      Precision1(i) = cm(i,i) / sum(cm(:,i));  % precision of every class
      Recall1(i) = cm(i,i) / sum(cm(i,:));     % recall of every class
      Fbeta1(i) = 2 * (Precision1(i) * Recall1(i)) / (Precision1(i) + Recall1(i));  % F1-score
    end
    
    % True positive(TP), Fake positive(FP), Fake negative(FN), True negative(TN)
    target_class = 1;  % the class targetted to calculate, 1 represent B2 structure
    TP = cm(target_class, target_class);
    FP = sum(cm(:, target_class))-TP;
    FN = sum(cm(target_class,:))-TP;
    TN = sum(sum(cm))-TP-FP-FN;
    % Precision, Recall, Accuracy, F-measure, and G-measure, targeting to classify B2 and Non-B2 alloys
    Precision(n1) = TP/(TP+FP);
    Recall(n1) = TP/(TP+FN);
    beta = 1;
    F_measure(n1) = (1+beta^2)*(Precision(n1)*Recall(n1))/(beta^2*Precision(n1)+Recall(n1));
    G_measure(n1) = sqrt(Recall(n1)*(TN/(TN+FP)));
    Accuracy(n1) = (TP+TN)/(TP+TN+FP+FN);

    plotconfusion(t, y);
end
xlswrite(Location1, Precision, 1,'A1:A400');
xlswrite(Location1, Recall, 1,'B1:B400');
xlswrite(Location1, F_measure, 1,'C1:C400');
xlswrite(Location1, G_measure, 1,'D1:D400');
xlswrite(Location1, Accuracy, 1,'E1:E400');