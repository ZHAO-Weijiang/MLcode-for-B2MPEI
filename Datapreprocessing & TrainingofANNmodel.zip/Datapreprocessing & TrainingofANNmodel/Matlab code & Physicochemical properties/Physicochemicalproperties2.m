% Function to calculate the physicochemical properties for pseudo binary system
function [a_mean, delta, tm_mean, delta_tm, ME, delta_ME, MS, en_mean, delta_en, vec_mean, delta_vec, bm_mean, delta_bm]=Physicochemicalproperties2(comp1, comp2, ele_frac1,  ele_frac2)
% ****************************************
%  index of the atoms included in the database
% ****************************************

ele_size1=zeros(size(comp1));
ele_en1=zeros(size(comp1));
ele_vec1=zeros(size(comp1));
ele_ym1=zeros(size(comp1));
ele_bm1=zeros(size(comp1));
ele_u1=zeros(size(comp1));
ele_tm1=zeros(size(comp1));
ele_den1=zeros(size(comp1));
ele_am1=zeros(size(comp1));
num1 = length(comp1);

ele_size2=zeros(size(comp2));
ele_en2=zeros(size(comp2));
ele_vec2=zeros(size(comp2));
ele_ym2=zeros(size(comp2));
ele_bm2=zeros(size(comp2));
ele_u2=zeros(size(comp2));
ele_tm2=zeros(size(comp2));
ele_den2=zeros(size(comp2));
ele_am2=zeros(size(comp2));
num2 = length(comp2);

size1=0;size2=0;
en1=0;en2=0;
vec1=0;vec2=0;
ym1=0;ym2=0;
bm1=0;bm2=0;
u1=0;u2=0;
tm1=0;tm2=0;
den1=0;den2=0;
am1=0;am2=0;

delta=0;
delta_en=0;
delta_vec=0;
delta_ym=0;
delta_bm=0;
delta_u=0;
delta_tm=0;
delta_den=0;
delta_am=0;
frac_sum1 = 0;
frac_sum2 = 0;
frac1 = zeros(1,num1);
frac2 = zeros(1,num2);

data1_ld = xlsread('properties.xlsx', 'C2:K84');   % Read the database
data2_ld = xlsread('mixingenthalpy.xlsx', 'C3:CG85');   % Read the mixing enthalpy in the database

radius = data1_ld(:, 1);         % Atomic size
enthalpy = data2_ld;             % Mixing enthalpy
tm = data1_ld(:, 2);             % Melting point
elec_neg = data1_ld(:, 3);       % Electronegativity
vec = data1_ld(:, 4);            % Valence electron concentration
y_modulus = data1_ld(:, 5);      % Young's modulus
b_modulus = data1_ld(:, 6);      % Bulk modulus
u = data1_ld(:, 7);              % Poisson's ratio
density = data1_ld(:, 8);        % Density
atomic_mass = data1_ld(:, 9);    % Relative atomic mass

for i = 1:num1
    frac_sum1 = frac_sum1 + ele_frac1(i);
end
for j = 1:num2
    frac_sum2 = frac_sum2 + ele_frac2(j);
end
for i = 1:num1
    frac1(i) = ele_frac1(i)/frac_sum1;
end
for j = 1:num2
    frac2(j) = ele_frac2(j)/frac_sum2;
end
for i = 1:num1
    key1 = comp1(i);
    %Element value of Group 1
    ele_size1(i)=radius(key1);
    ele_en1(i)=elec_neg(key1);
    ele_vec1(i)=vec(key1);
    ele_ym1(i)=y_modulus(key1);
    ele_bm1(i)=b_modulus(key1);
    ele_u1(i)=u(key1);
    ele_tm1(i)=tm(key1);
    ele_den1(i)=density(key1);
    ele_am1(i)=atomic_mass(key1);
    %Average of Group 1
    size1=size1+frac1(i)*ele_size1(i);
    en1=en1+frac1(i)*ele_en1(i);
    vec1=vec1+frac1(i)*ele_vec1(i);
    ym1=ym1+frac1(i)*ele_ym1(i);
    bm1=bm1+frac1(i)*ele_bm1(i);
    u1=u1+frac1(i)*ele_u1(i);
    tm1=tm1+frac1(i)*ele_tm1(i);
    den1=den1+frac1(i)*ele_den1(i);
    am1=am1+frac1(i)*ele_am1(i);
end
for j = 1:num2
    key2 = comp2(j);
    ele_size2(j)=radius(key2);
    ele_en2(j)=elec_neg(key2);
    ele_vec2(j)=vec(key2);
    ele_ym2(j)=y_modulus(key2);
    ele_bm2(j)=b_modulus(key2);
    ele_u2(j)=u(key2);
    ele_tm2(j)=tm(key2);
    ele_den2(j)=density(key2);
    ele_am2(j)=atomic_mass(key2);
    %Average of Group 2
    size2=size2+frac2(j)*ele_size2(j);
    en2=en2+frac2(j)*ele_en2(j);
    vec2=vec2+frac2(j)*ele_vec2(j);
    ym2=ym2+frac2(j)*ele_ym2(j);
    bm2=bm2+frac2(j)*ele_bm2(j);
    u2=u2+frac2(j)*ele_u2(j);
    tm2=tm2+frac2(j)*ele_tm2(j);
    den2=den2+frac2(j)*ele_den2(j);
    am2=am2+frac2(j)*ele_am2(j);
end
MS1 = 0; MS2 = 0;
ME = 0; delta_ME = 0;
a_mean = 4*(frac_sum1*size1+frac_sum2*size2)/((frac_sum1+frac_sum2)*sqrt(3));
tm_mean = (frac_sum1*tm1+frac_sum2*tm2)/(frac_sum1+frac_sum2);
en_mean = (frac_sum1*en1+frac_sum2*en2)/(frac_sum1+frac_sum2);
vec_mean = (frac_sum1*vec1+frac_sum2*vec2)/(frac_sum1+frac_sum2);
bm_mean = (frac_sum1*bm1+frac_sum2*bm2)/(frac_sum1+frac_sum2);
delta = sqrt(frac_sum1/(frac_sum1+frac_sum2)*(1-4*size1/(a_mean*sqrt(3)))^2+frac_sum2/(frac_sum1+frac_sum2)*(1-4*size2/(a_mean*sqrt(3)))^2)*100;
delta_tm = sqrt(frac_sum1/(frac_sum1+frac_sum2)*(1-tm1/tm_mean)^2+frac_sum2/(frac_sum1+frac_sum2)*(1-tm2/tm_mean)^2);
delta_en = sqrt(frac_sum1/(frac_sum1+frac_sum2)*(1-en1/en_mean)^2+frac_sum2/(frac_sum1+frac_sum2)*(1-en2/en_mean)^2);
delta_vec = sqrt(frac_sum1/(frac_sum1+frac_sum2)*(1-vec1/vec_mean)^2+frac_sum2/(frac_sum1+frac_sum2)*(1-vec2/vec_mean)^2);
delta_bm = sqrt(frac_sum1/(frac_sum1+frac_sum2)*(1-bm1/bm_mean)^2+frac_sum2/(frac_sum1+frac_sum2)*(1-bm2/bm_mean)^2);

for i = 1:num1 
    MS1 = MS1 - 8.31446261815324*frac1(i)*log(frac1(i));
end
for j = 1:num2
    MS2 = MS2 - 8.31446261815324*frac2(j)*log(frac2(j));
end
MS = frac_sum1*MS1+frac_sum2*MS2;

for i = 1:num1 
    for j = 1:num2
     key1 = comp1(i);
     key2 = comp2(j);
     ME = ME + 4*enthalpy(key1, key2)*ele_frac1(i)*ele_frac2(j);
    end
end
for i = 1:num1 
    for j = 1:num2
     key1 = comp1(i);
     key2 = comp2(j);
     delta_ME = delta_ME + ele_frac1(i)*ele_frac2(j)*(enthalpy(key1, key2)-ME)^2;
    end
end
delta_ME = sqrt(delta_ME);
end