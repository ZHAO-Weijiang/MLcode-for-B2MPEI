clc;
clear;
%***************************************************************************************************************************************
%the code aims to perform principal component analysis on the whole dataset derived from random-sublattice-based and classic descriptors
%***************************************************************************************************************************************

% read the normalized values of 18 random-sublattice-based descriptors of whole dataset
  feature = xlsread('D:\Datapreprocessing & TrainingofANNmodel\Fe-Co-Ni-Ti-Zr\features.xlsx',1,'A1:R1000');

% read the normalized values of 16 classic descriptors of whole dataset
  % feature = xlsread('D:\Machine learning of B2 MPEI1\Fe-Co-Ni-Ti-Zr\features.xlsx',2,'A1:P1000'); 

n=length(feature(1,:));

for i=1:n
    feature_n(:,i)=rescale(feature(:,i));
end

[coeff,score,latent]=pca(feature_n);