function avg_enthalpy = MinimizeMixingEnthalpy(group1, group2, frac1, frac2, enthalpy, comp)
    num1 = numel(group1);
    num2 = numel(group2);
    enthalpy_sum = 0;
    frac1_sum = 0;
    frac2_sum = 0;
    comp_map = containers.Map(comp, 1:numel(comp));
    for i = 1:num1
        frac1_sum = frac1_sum + frac1(i);
    end
    for j = 1:num2
        frac2_sum = frac2_sum + frac2(j);
    end
    % for i = 1:n
    %     frac(i) = frac(i)/frac_sum;
    % end
    for i = 1:num1
        for j = 1:num2
            key1 = group1(i);
            key2 = group2(j);
            if isKey(comp_map, key1) && isKey(comp_map, key2)
                idx1 = comp_map(key1);
                idx2 = comp_map(key2);
            enthalpy_sum = enthalpy_sum + enthalpy(idx1, idx2)*frac1(i)*frac2(j);
            else
                warning('Key not found in comp: %d or %d', key1, key2);
            end
        end
        % disp(enthalpy_sum)
    end
    if (frac1_sum == 0) && (frac2_sum == 0)
        avg_enthalpy = Inf;
    else
        avg_enthalpy = enthalpy_sum;
    end
end