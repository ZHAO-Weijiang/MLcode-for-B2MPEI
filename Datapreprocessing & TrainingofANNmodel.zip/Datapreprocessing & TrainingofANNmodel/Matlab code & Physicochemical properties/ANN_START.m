clc;
clear all;
%*************************************************************************
%the code aims to input the features and the labels of the neutral network
%*************************************************************************
Location = 'D:\Datapreprocessing & TrainingofANNmodel\Fe-Co-Ni-Ti-Zr\features.xlsx';

% read the labels and random-sublattice-based descriptors
features = xlsread(Location,1,'A1:R1000');
labels = xlsread(Location,1,'S1:U1000');

% read the labels and classic descriptors
% features = xlsread(Location,2,'A1:P1000');
% labels = xlsread(Location,2,'Q1:S1000');

training_input=cat(2,features,labels);
