clc;
clear all;
%*********************************************************************************************************************************************
%the code aims to train a series of ANN models and output their F-measure values to confirm the optimal combination of hyperparameters
%*********************************************************************************************************************************************

% Starting timing
totalStartTime = tic;

% The file path of input data and output data
Location = 'D:\Datapreprocessing & TrainingofANNmodel\Fe-Co-Ni-Ti-Zr\features.xlsx';
Location1 = 'D:\Datapreprocessing & TrainingofANNmodel\Fe-Co-Ni-Ti-Zr\Perfomance of different hyperparameters.xlsx';

% Read the input data and transfer the one-hot label into class label
features = xlsread(Location,1,'A1:R1000');
labels = xlsread(Location,1,'S1:U1000');
t_cate = categorical(vec2ind(labels')');

Num = size(features,2);
n = width(features);
Nums = 5400;
Precision = zeros(Nums, 1);
Recall = zeros(Nums, 1);
F_measure = zeros(Nums, 1);
G_measure = zeros(Nums, 1);
Accuracy = zeros(Nums, 1);

% Using the structure array to store the hyperparameters
ParamRecord(Nums) = struct('Optimizer', '', 'LearningRate', 0, 'Regularization', 0, 'Dropout', 0);

% Definition of search space of hyperparameters
optimizers = {'sgdm', 'adam', 'rmsprop'};  % Optimizers
learningRates = [0.001, 0.01, 0.1];        % Initial learning rates
regularizationValues = [0.01, 0.1];        % L2 regularization intensities
dropoutRates = [0.3, 0.4, 0.5];            % Dropout rates

% Separation of datasets for training, tesing and validating
rng('default');
totalSamples = length(features);
trainRatio = 0.7;
valRatio = 0.15;
testRatio = 0.15;

trainInd = 1:floor(totalSamples*trainRatio);
valInd = (max(trainInd)+1):(max(trainInd)+floor(totalSamples*valRatio));
testInd = (max(valInd)+1):totalSamples;

% Create parallel pool and start parallel calculation
if isempty(gcp('nocreate'))
    parpool('local', 2);  % tuning the number of cores
end

parfor n1 = 1:Nums
    iterStartTime = tic;

    % Random selection of hyperparameters
    selectedOptimizer = optimizers{randi(length(optimizers))};
    selectedLR = learningRates(randi(length(learningRates)));
    selectedReg = regularizationValues(randi(length(regularizationValues)));
    selectedDropout = dropoutRates(randi(length(dropoutRates)));

    % Import the hyperparameters into structure array
    ParamRecord(n1).Optimizer = selectedOptimizer;
    ParamRecord(n1).LearningRate = selectedLR;
    ParamRecord(n1).Regularization = selectedReg;
    ParamRecord(n1).Dropout = selectedDropout;

    % Random selection of features
    Ran = randperm(Num,n);
    Featureset = features(:, Ran);

    % Construction of neural network with dropout layer
    layers = [
        featureInputLayer(n)
        fullyConnectedLayer(20, ...
        'WeightL2Factor',selectedReg)  % Regularization of weight
        sigmoidLayer
        dropoutLayer(selectedDropout)  % Addtion of dropout layer
        fullyConnectedLayer(3)
        softmaxLayer
        classificationLayer
    ];

    % Construction of training options
    options = trainingOptions(selectedOptimizer, ...
        'Plots', 'none', ...
        'MaxEpochs', 1000, ...
        'ValidationFrequency', 30, ...
        'ValidationPatience', 6, ...         % Earky stopping mechanism
        'InitialLearnRate', selectedLR, ...  % Learning rate 
        'ExecutionEnvironment', 'cpu', ...
        'GradientThreshold', 1, ...
        'Verbose', false, ...
        'ValidationData', {Featureset(valInd,:), t_cate(valInd)});

    % Training the Network
    net = trainNetwork(Featureset(trainInd,:), t_cate(trainInd), layers, options);

    % Predicting all the samples
    y = predict(net, Featureset);

    % Transfering the results into index for calculation of confusion matrix
    tind = vec2ind(labels');
    yind = vec2ind(y');
    cm = confusionmat(tind, yind);

    % Calculation of parameters to evaluate the performance of ANN
    target_class = 1;
    TP = cm(target_class, target_class);
    FP = sum(cm(:, target_class)) - TP;
    FN = sum(cm(target_class, :)) - TP;
    TN = sum(sum(cm)) - TP - FP - FN;

    Precision(n1) = TP/(TP+FP);
    Recall(n1) = TP/(TP+FN);
    F_measure(n1) = 2 * (Precision(n1) * Recall(n1)) / (Precision(n1) + Recall(n1));
    G_measure(n1) = sqrt(Recall(n1) * (TN/(TN+FP)));
    Accuracy(n1) = (TP+TN)/(TP+TN+FP+FN);

    % Displaying of iteration progress
    iterTime = toc(iterStartTime);
    fprintf('Finished iteration %d/%d (Optimizer: %s, LR: %.3f, Reg: %.2f, Dropout: %.1f, Time cost: %.2f second)\n',...
    n1, Nums, selectedOptimizer, selectedLR, selectedReg, selectedDropout, iterTime);
end

% Storage of final results in workspace
paramStrings = cell(Nums, 1);
for i = 1:Nums
    paramStrings{i} = sprintf('%s (LR=%.3f, Reg=%.2f, Drop=%.1f)',...
        ParamRecord(i).Optimizer, ParamRecord(i).LearningRate, ...
        ParamRecord(i).Regularization, ParamRecord(i).Dropout);
end

% Output the results to Excel file
% xlswrite(Location1, {'Precision','Recall','F_measure','G_measure','Accuracy','Hyperparameters'}, 1, 'A1:F1');
% xlswrite(Location1, Precision, 1, 'A2:A5401');
% xlswrite(Location1, Recall, 1, 'B2:B5401');
% xlswrite(Location1, F_measure, 1, 'C2:C5401');
% xlswrite(Location1, G_measure, 1, 'D2:D5401');
% xlswrite(Location1, Accuracy, 1, 'E2:E5401');
% xlswrite(Location1, paramStrings, 1, 'F2:F5401');

% Timing stop
totalTime = toc(totalStartTime);
fprintf('All iterations have been completed! Totaltime-consuming: %.2f minutes\n', totalTime/60);
fprintf('The results have been storaged in: %s\n', Location1);

% Shut down the parpool to free the memory
if ~isempty(gcp('nocreate'))
    delete(gcp);
end