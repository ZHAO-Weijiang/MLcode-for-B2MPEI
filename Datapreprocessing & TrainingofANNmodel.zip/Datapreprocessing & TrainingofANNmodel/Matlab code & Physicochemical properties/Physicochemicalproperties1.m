function [a_mean, delta, tm_mean, delta_tm, ME, delta_ME, MS, en_mean, delta_en, vec_mean, delta_vec, bm_mean, delta_bm]=Physicochemicalproperties1(comp, ele_frac, data1_ld, data2_ld)

ntotal = length(comp);
ele_size = data1_ld(comp, 1);         % Atomic size
enthalpy = data2_ld(comp, comp);    % Mixing enthalpy
ele_tm = data1_ld(comp, 2);             % Melting point
ele_en = data1_ld(comp, 3);       % Electronegativity
ele_vec = data1_ld(comp, 4);            % Valence electron concentration
ele_ym = data1_ld(comp, 5);      % Young's modulus
ele_bm = data1_ld(comp, 6);      % Bulk modulus
ele_u = data1_ld(comp, 7);              % Poisson's ratio

ele_frac = ele_frac / sum(ele_frac);

% *************************************************************************
%   Calculate the mixing entropy
% *************************************************************************
MS=0;
n = length(ele_frac);
R=8.31446261815324;
for i=1:n
    MS=MS-R*ele_frac(i)*log(ele_frac(i));
end
% *************************************************************************
%   Calculate the delta/local atomic size difference  
% *************************************************************************
a_mean=0;
delta=0;
for  i=1:ntotal
    a_mean=a_mean+ele_size(i)*ele_frac(i);      %the average atomic radius
end
for  i=1:ntotal
    delta=delta+ele_frac(i)*(1-ele_size(i)/a_mean)^2;
end
disp(ele_size);
delta=100*sqrt(delta);
% *************************************************************************
%   Calculate the electronegativity/bulk modulus/young's modulus/poisson's
%   ratio/shear modulus difference/melting point
% *************************************************************************
en_mean=0; 
ym_mean=0;
gm_mean=0;
gm=zeros(1,ntotal);
bm_mean=0;
u_mean=0;
tm_mean=0;
for  i=1:ntotal
    en_mean=en_mean+ele_en(i)*ele_frac(i);      %the average electronegativity
    ym_mean=ym_mean+ele_ym(i)*ele_frac(i);      %the average young's modulus
    gm(1,i)=ele_ym(i)/(2*(1+ele_u(i)));    %the shear modulus
    gm_mean=gm_mean+gm(1,i)*ele_frac(i);     %the average shear modulus
    bm_mean=bm_mean+ele_bm(i)*ele_frac(i);      %the average bulk modulus
    u_mean=u_mean+ele_u(i)*ele_frac(i);      %the average poisson's ratio
    tm_mean=tm_mean+ele_tm(i)*ele_frac(i);       %the average melting point
end
delta_en=0;
delta_ym=0;
delta_gm=0;
delta_bm=0;
delta_u=0;
delta_tm=0;
for  i=1:ntotal
    delta_en=delta_en+ele_frac(i)*(ele_en(i)-en_mean)^2;
    delta_ym=delta_ym+ele_frac(i)*(1-ele_ym(i)/ym_mean)^2;
    delta_gm=delta_gm+ele_frac(i)*(1-gm(1,i)/gm_mean)^2;
    delta_bm=delta_bm+ele_frac(i)*(1-ele_bm(i)/bm_mean)^2;
    delta_u=delta_u+ele_frac(i)*(1-ele_u(i)/u_mean)^2;
    delta_tm=delta_tm+ele_frac(i)*(1-ele_tm(i)/tm_mean)^2;
end
delta_en=sqrt(delta_en);
delta_ym=sqrt(delta_ym);
delta_gm=sqrt(delta_gm);
delta_bm=sqrt(delta_bm);
delta_u=sqrt(delta_u);
delta_tm=sqrt(delta_tm);
% *************************************************************************
%   Calculate the VEC
% *************************************************************************
vec_mean=0;                              
for  i=1:ntotal
    vec_mean=vec_mean+ele_vec(i)*ele_frac(i);      %the average VEC
end
delta_vec=0;
for  i=1:ntotal
    delta_vec=delta_vec+ele_frac(i)*(ele_vec(i)-vec_mean)^2;      %the average VEC
end
delta_vec=sqrt(delta_vec);
% *************************************************************************
%   Calculate the mixing enthalpy and its difference
% *************************************************************************
n = length(ele_frac);
ME=0;
for  i=1:n-1
    for  j=i+1:n
    key1 = comp(i);
    key2 = comp(j);
    for k=1:ntotal
        if key1==comp(k)
            key1=k;
        end
    end
    for l=1:ntotal
        if key2==comp(l)
            key2=l;
        end
    end
    ME=ME+4*ele_frac(i)*ele_frac(j)*enthalpy(key1,key2);
    end
end
delta_ME=0;
ME_ij=zeros(n*(n-1)/2,1);
for  i=1:n-1
    for  j=i+1:n
    key1 = comp(i);
    key2 = comp(j);
    for k=1:ntotal
        if key1==comp(k)
            key1=k;
        end
    end
    for l=1:ntotal
        if key2==comp(l)
            key2=l;
        end
    end
    ME_ij(i*j)=ele_frac(i)*ele_frac(j)*(enthalpy(key1,key2)-ME)^2;
         delta_ME=delta_ME+ME_ij(i*j);
    end
end
delta_ME=sqrt(delta_ME);
%**************************************************************************
disp([num2str(a_mean),' ',num2str(delta),' ',num2str(tm_mean),' ',num2str(delta_tm),' ',num2str(ME),' ',num2str(delta_ME),' ',num2str(MS),' ',num2str(en_mean),' ',num2str(delta_en),' ',num2str(vec_mean),' ',num2str(delta_vec),' ',num2str(bm_mean),' ',num2str(delta_bm)]);
