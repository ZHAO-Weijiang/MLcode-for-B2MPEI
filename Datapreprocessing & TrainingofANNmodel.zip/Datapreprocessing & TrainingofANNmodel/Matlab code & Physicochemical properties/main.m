clc;
clear all;

% Define elment Map for calculation
elementMap = struct('Li', 3, 'Be', 4, 'B', 5, 'C', 6, 'N', 7, 'Na', 11, ...
    'Mg', 12, 'Al', 13, 'Si', 14, 'P', 15, 'Ca', 20, 'Sc', 21, 'Ti', 22, ...
    'V', 23, 'Cr', 24, 'Mn', 25, 'Fe', 26, 'Co', 27, 'Ni', 28, 'Cu', 29, ...
    'Zn', 30, 'Ga', 31, 'Ge', 32, 'Sr', 38, 'Y', 39, 'Zr', 40, 'Nb', 41, ...
    'Mo', 42, 'Tc', 43, 'Ru', 44, 'Rh', 45, 'Pd', 46, 'Ag', 47, 'Cd', 48, ...
    'In', 49, 'Sn', 50, 'Sb', 51, 'La', 57, 'Ce', 58, 'Pr', 59, 'Nd', 60, ...
    'Pm', 61, 'Sm', 62, 'Eu', 63, 'Gd', 64, 'Tb', 65, 'Dy', 66, 'Ho', 67, ...
    'Er', 68, 'Tm', 69, 'Yb', 70, 'Lu', 71, 'Hf', 72, 'Ta', 73, 'W', 74, ...
    'Re', 75, 'Os', 76, 'Ir', 77, 'Pt', 78, 'Au', 79, 'Pb', 82, 'Bi', 83);

% Read the alloy dataset from Excel file
Location = 'D:\Datapreprocessing & TrainingofANNmodel\Fe-Co-Ni-Ti-Zr\Dataset_18PI.xlsx';
Location1 = 'D:\Datapreprocessing & TrainingofANNmodel\Fe-Co-Ni-Ti-Zr\Dataset_16CL.xlsx';
Range = 'B2:D397'; Range1 = 'E2:V397'; Range2 = 'E2:T397';

[num, txt] = xlsread(Location,1,Range);
data1_ld = xlsread('properties.xlsx','C2:K84');   %read the database
data2_ld = xlsread('mixingenthalpy.xlsx','C3:CG85');  %read the mixing enthalpy in the database
component = txt(:,1);
fraction = txt(:,2);
No = num;
Num = length(component);

% Initialize composition and feature variance
Com = cell(Num,1);
features_basic = zeros(Num,16);
features_PBS = zeros(Num,18);

% Create parallel pool and start parallel calculation
if isempty(gcp('nocreate'))
    parpool('local', 3); 
end
parfor i = 1:Num
    Com(i) = regexp(component(i), '\s+', 'split');
    Fra(i) = regexp(fraction(i), '\s+', 'split');
    s = Com{i};
    t = Fra{i};
    % Initialize composition and fraction variance
    comp = zeros(No(i), 1);
    ele_frac = zeros(No(i), 1);
    
    % Search for corresponding elements in elementMap
    for j = 1:No(i)
        comp(j) = elementMap.(s{j});
        ele_frac(j) = str2double(t{j});
    end
    
    % Calculation of basic and PBS features
    features_basic(i, :) = calculatefeatures(comp, ele_frac, data1_ld, data2_ld);
    features_PBS(i, :) = calculatefeatures1(comp, ele_frac, data1_ld, data2_ld);
end

% Shut down the parpool to free the memory
delete(gcp('nocreate'));

% Write the data into Excel file
xlswrite(Location, features_PBS, 1, Range1);   %write the physics-informed descriptors into excel
xlswrite(Location1, features_basic, 1, Range2);   %write the classic descriptors into excel